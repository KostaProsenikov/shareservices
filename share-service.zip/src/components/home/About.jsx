import React from 'react';

export default () => (
    <div className="about">
        <h2>Welcome to Catalog Services</h2>
        <p>
            Staff sharing and discussion
        </p>
        <p>Please login to continue</p>
    </div>
);